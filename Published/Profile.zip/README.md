# Khartoum-Dataset

A vatSys Dataset for the Khartoum FIR on VATSIM.
